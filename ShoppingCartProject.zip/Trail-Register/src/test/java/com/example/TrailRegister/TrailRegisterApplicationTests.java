package com.example.TrailRegister;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrailRegisterApplicationTests {

	@Test
	void contextLoads() {
	}

}
