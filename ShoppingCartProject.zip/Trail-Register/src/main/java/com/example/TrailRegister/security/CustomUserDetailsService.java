package com.example.TrailRegister.security;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.TrailRegister.entity.RegisterDetails;
import com.example.TrailRegister.repo.RegisterRepo;


@Service
public class CustomUserDetailsService implements UserDetailsService {

	@Autowired
	private RegisterRepo registerRepo;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
			
		RegisterDetails existingUser = registerRepo.findByUsername(username).orElseThrow(() -> 
				new UsernameNotFoundException("User not found"));
		
		return new org.springframework.security.core.userdetails.User(
				existingUser.getUsername(), existingUser.getPassword(), new ArrayList<>());
	}

}