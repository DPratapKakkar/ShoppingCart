package com.example.TrailRegister.repo;



import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.TrailRegister.entity.RegisterDetails;



//import com.deloitte.Feignempms.entity.Employee;



@Repository
public interface RegisterRepo extends JpaRepository<RegisterDetails, String> {

	Boolean existsByUsername(String username);
	
	
	Optional<RegisterDetails> findByUsername(String username);
  //  @Query("select e from Detail e where e.username=:username")
  //  public List<RegisterDetails> getAllEmployeesBasedOnDeptId(String username);
}