package com.example.TrailRegister.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.TrailRegister.entity.RegisterDetails;
import com.example.TrailRegister.repo.RegisterRepo;

//import com.deloitte.Feignempms.repo.EmployeeRepo;

//import com.deloitte.Feignempms.entity.Employee;
//import com.deloitte.Feignempms.repo.EmployeeRepo;

@RestController
@RequestMapping
public class RegisterController {

	@Autowired
	RegisterRepo registerRepo;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Configuration
    class config {
        
        @Bean
        @LoadBalanced
        public RestTemplate restTemplate() {
            return new RestTemplate();
        }
    }
	
	 @GetMapping("/getAll")
	    public ResponseEntity<List<RegisterDetails>> getUsers(){
	        return new ResponseEntity<List<RegisterDetails>>(registerRepo.findAll(), HttpStatus.OK);
	    }
	    
	    @PostMapping("/add")
	    public ResponseEntity<RegisterDetails> addDetail(@RequestBody RegisterDetails details){
	        return new ResponseEntity<RegisterDetails>(registerRepo.save(details), HttpStatus.OK);
	    }
	    
	    @GetMapping(value = "/getCustomerProducts")
	    public List<Object> getCustomerProducts() {
	        Object objects = restTemplate.getForObject("http://product-service/prod/getAll", Object.class);
	        return Arrays.asList(objects);
	    }
	    
	    @GetMapping(value = "/getCartProducts")
		public List<Object> getCartProducts() {
			Object objects = restTemplate.getForObject("http://cart-service/cart/getAll", Object.class);
			return Arrays.asList(objects);
		}
		
		@GetMapping(value = "/getByCName/{cname}")
		public Object getByCName(@PathVariable String cname) {
			Object response = restTemplate.exchange("http://cart-service/cart/getByCName/{cname}", HttpMethod.GET, null, new ParameterizedTypeReference<Object>() {
			}, cname).getBody();
			return response;
		}
	}

	@Configuration
	class config{
		@Bean
		@LoadBalanced
		public RestTemplate restTemplate() {
			return new RestTemplate();
		}
	}
	